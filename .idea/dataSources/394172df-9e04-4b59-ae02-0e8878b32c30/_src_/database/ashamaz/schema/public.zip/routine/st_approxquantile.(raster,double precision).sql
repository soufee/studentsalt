CREATE FUNCTION st_approxquantile (rast raster, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ( public._ST_quantile($1, 1, TRUE, 0.1, ARRAY[$2]::double precision[])).value 
$$
