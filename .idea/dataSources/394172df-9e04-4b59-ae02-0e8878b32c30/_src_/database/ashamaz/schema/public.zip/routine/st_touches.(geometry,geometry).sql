CREATE FUNCTION st_touches (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Touches($1,$2)
$$
