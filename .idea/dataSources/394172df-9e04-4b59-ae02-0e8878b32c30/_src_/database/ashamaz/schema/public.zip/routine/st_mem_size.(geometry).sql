CREATE FUNCTION st_mem_size (geometry) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT public._postgis_deprecate('ST_Mem_Size', 'ST_MemSize', '2.2.0');
    SELECT public.ST_MemSize($1);
  
$$
