CREATE FUNCTION st_rotatez (geometry, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_Rotate($1, $2)
$$
