CREATE FUNCTION is_contained_2d (geometry, box2df) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $2 OPERATOR(public.~) $1;
$$
