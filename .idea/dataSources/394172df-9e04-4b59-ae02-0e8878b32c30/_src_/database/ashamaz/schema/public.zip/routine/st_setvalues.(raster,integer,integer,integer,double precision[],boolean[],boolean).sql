CREATE FUNCTION st_setvalues (rast raster, nband integer, x integer, y integer, newvalueset double precision[], noset boolean[] DEFAULT NULL::boolean[], keepnodata boolean DEFAULT false) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public._ST_setvalues($1, $2, $3, $4, $5, $6, FALSE, NULL, $7) 
$$
