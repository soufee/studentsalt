CREATE FUNCTION dropgeometrytable (table_name character varying) RETURNS text
	LANGUAGE sql
AS $$
 SELECT DropGeometryTable('','',$1) 
$$
