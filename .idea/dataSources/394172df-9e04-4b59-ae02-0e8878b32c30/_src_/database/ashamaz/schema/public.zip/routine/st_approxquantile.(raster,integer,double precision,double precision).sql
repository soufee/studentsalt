CREATE FUNCTION st_approxquantile (rast raster, nband integer, sample_percent double precision, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ( public._ST_quantile($1, $2, TRUE, $3, ARRAY[$4]::double precision[])).value 
$$
