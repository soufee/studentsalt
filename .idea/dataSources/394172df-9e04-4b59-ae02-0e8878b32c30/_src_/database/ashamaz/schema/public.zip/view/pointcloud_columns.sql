CREATE VIEW pointcloud_columns AS
SELECT n.nspname AS schema,
    c.relname AS "table",
    a.attname AS "column",
    pc_typmod_pcid(a.atttypmod) AS pcid,
    p.srid,
    t.typname AS type
   FROM pg_class c,
    pg_type t,
    pg_namespace n,
    (pg_attribute a
     LEFT JOIN pointcloud_formats p ON ((pc_typmod_pcid(a.atttypmod) = p.pcid)))
  WHERE ((t.typname = ANY (ARRAY['pcpatch'::name, 'pcpoint'::name])) AND (a.attisdropped = false) AND (a.atttypid = t.oid) AND (a.attrelid = c.oid) AND (c.relnamespace = n.oid) AND (NOT pg_is_other_temp_schema(c.relnamespace)) AND has_table_privilege(c.oid, 'SELECT'::text))