CREATE FUNCTION st_area (text) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ST_Area($1::public.geometry);  
$$
