CREATE FUNCTION st_mapalgebra (rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public.ST_mapalgebra($1, 1, $2, $3, $4) 
$$
