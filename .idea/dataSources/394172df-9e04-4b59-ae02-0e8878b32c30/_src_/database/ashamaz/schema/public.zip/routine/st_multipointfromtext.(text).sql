CREATE FUNCTION st_multipointfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_MPointFromText($1)
$$
