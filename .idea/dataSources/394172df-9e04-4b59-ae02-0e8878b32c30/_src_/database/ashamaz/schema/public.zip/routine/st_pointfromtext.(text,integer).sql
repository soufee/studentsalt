CREATE FUNCTION st_pointfromtext (text, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(public.ST_GeomFromText($1, $2)) = 'POINT'
	THEN public.ST_GeomFromText($1, $2)
	ELSE NULL END
	
$$
