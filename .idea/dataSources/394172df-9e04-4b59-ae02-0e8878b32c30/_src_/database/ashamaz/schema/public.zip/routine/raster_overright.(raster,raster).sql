CREATE FUNCTION raster_overright (raster, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::public.geometry &> $2::public.geometry
$$
