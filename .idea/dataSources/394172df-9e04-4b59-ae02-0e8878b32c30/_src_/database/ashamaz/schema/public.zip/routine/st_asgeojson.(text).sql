CREATE FUNCTION st_asgeojson (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT public._ST_AsGeoJson(1, $1::public.geometry,15,0);  
$$
