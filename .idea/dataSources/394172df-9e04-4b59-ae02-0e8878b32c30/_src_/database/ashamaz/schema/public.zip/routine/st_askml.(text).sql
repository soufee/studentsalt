CREATE FUNCTION st_askml (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT public._ST_AsKML(2, $1::public.geometry, 15, null);  
$$
