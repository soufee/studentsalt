CREATE FUNCTION st_stddev4ma (value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[]) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT stddev(unnest) FROM unnest($1) 
$$
