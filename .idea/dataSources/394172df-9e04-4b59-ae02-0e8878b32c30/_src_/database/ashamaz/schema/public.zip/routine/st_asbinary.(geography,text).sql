CREATE FUNCTION st_asbinary (geography, text) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT public.ST_AsBinary($1::public.geometry, $2);  
$$
