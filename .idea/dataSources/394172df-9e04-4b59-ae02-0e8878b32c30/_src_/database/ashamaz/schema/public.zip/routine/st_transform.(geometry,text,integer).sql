CREATE FUNCTION st_transform (geom geometry, from_proj text, to_srid integer) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT postgis_transform_geometry($1, $2, proj4text, $3)
FROM spatial_ref_sys WHERE srid=$3;
$$
