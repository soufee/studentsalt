CREATE FUNCTION st_rescale (rast raster, scalexy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT  public._ST_GdalWarp($1, $3, $4, NULL, $2, $2) 
$$
