CREATE FUNCTION st_mapalgebrafct (rast raster, onerastuserfunc regprocedure) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, NULL) 
$$
